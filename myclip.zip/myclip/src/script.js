// React and ReactDOM are already included via External Scripts

const { useState, useEffect, useRef } = React;

const VideoPlayer = ({ src }) => {
  const videoRef = useRef(null);

  useEffect(() => {
    const player = videojs(videoRef.current, {
      controls: true,
      autoplay: false,
      preload: "auto"
    });

    return () => {
      player.dispose();
    };
  }, []);

  return (
    <div data-vjs-player>
      <video ref={videoRef} className="video-js">
        <source src={src} type="video/mp4" />
      </video>
    </div>
  );
};

const App = () => {
  const videoSrc = "https://www.w3schools.com/html/mov_bbb.mp4"; // Sample video URL

  return (
    <div>
      <h1>Video Player</h1>
      <VideoPlayer src={videoSrc} />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
